#!/bin/bash

echo "$(date): executed script" >> /var/log/cron.log 2>&1

# Enter details here...
docker run -d --rm --name certbot -v "/home/chronos/conf:/etc/letsencrypt" -v "/var/lib/letsencrypt:/var/lib/letsencrypt" -p 80:80 certbot/certbot renew -n

